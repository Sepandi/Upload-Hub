namespace Utils
{
    float RGBtoFloat(int rgbValue){
        return 0.003921568627451*rgbValue;
    }
        template <typename anyType>
    void Log(anyType object){
        #ifdef __APPLE__
            std::cout << "\033[0;106m\033[36m[DEBUG]\033[0m\033[36m [ " << object << " ]\033[0m" << std::endl; 
        #else
            std::cout << "[DEBUG] [ " << object << " ]" << std::endl; 
        #endif
        
        
    }
    template <typename anyType>
    void Error(anyType object) {
        #ifdef __APPLE__
            std::cout << "\033[43m\033[1;31m[ERROR]\033[0m\033[1;31m [ " << object << " ]\033[0m" << std::endl; 
        #else
            std::cout << "[ERROR] [ " << object << " ]" << std::endl; 
        #endif
    }

    inline bool FileExists(const std::string& name) {
        if (FILE *file = fopen(name.c_str(), "r")) {
            fclose(file);
            return true;
        } else {
            return false;
        }   
    }
    bool DirectoryExists(std::string name){
        #ifndef __EMSCRIPTEN__
            return std::filesystem::is_directory(name)||std::filesystem::exists(name);
        #else
            return true;
        #endif
    }
}
