#include "SDL2/SDL.h"
#include <iostream>
#include <string>
#include <filesystem>
#include <vector>
#include "glad/glad.h"
#define STB_IMAGE_IMPLEMENTATION 
#include "stb_image.h"

namespace Aura{
    #include "Utils.hpp"
    #include "Window.hpp"
    #include "Vector3.hpp"
    #include "Cube.hpp"
}
