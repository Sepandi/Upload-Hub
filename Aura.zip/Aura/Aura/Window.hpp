
using namespace std;
namespace Window{
    SDL_Window *window = NULL;
    SDL_GLContext context = NULL;
    SDL_Event events;
    int width,height;
    const Uint8 *isDown = SDL_GetKeyboardState(NULL);
    
    void CreateWindow()
    {
        if(SDL_Init(SDL_INIT_VIDEO) < 0)
        {
            exit(1);
        }
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,2);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,1);

        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);

        window = SDL_CreateWindow("CUBE",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,800,800,SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL | SDL_WINDOWEVENT_SIZE_CHANGED|SDL_WINDOW_RESIZABLE);
        context = SDL_GL_CreateContext(window);
        if (context == NULL)
        {
            Utils::Error("Could not Create OpenGL Context");
            exit(1);
        }
        SDL_GetWindowSize(window,&width,&height);
        gladLoadGLLoader(SDL_GL_GetProcAddress);
        stbi_set_flip_vertically_on_load(true); 
    }

    void UpdateWindow()
    {
        // Ending
        glViewport(0,0,width,width);
        glMatrixMode (GL_PROJECTION);
        glLoadIdentity();
        glFrustum(-1.0, 1.0, -1.0, 1.0, 5, 100);
        glMatrixMode (GL_MODELVIEW);
        glFinish();
        SDL_GL_SwapWindow(window);



        // Starting 
        while (SDL_PollEvent(&events))
        {
            if (events.type == SDL_QUIT)
            {
                exit(0);
            }
            else if (events.type == SDL_WINDOWEVENT)
            {
                if(events.window.event == SDL_WINDOWEVENT_RESIZED) 
                {
                    SDL_GetWindowSize(window,&width,&height);
                }
            }
        }
        SDL_PumpEvents();

        isDown = SDL_GetKeyboardState(NULL);
        glClearColor(Utils::RGBtoFloat(66),Utils::RGBtoFloat(191),Utils::RGBtoFloat(232),1);
        glColor3f(1,1,1);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glDepthMask(true);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LESS);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glEnable(GL_BLEND);
        glEnable(GL_COLOR_MATERIAL);


        
    }

    void Quit()
    {
        SDL_GL_DeleteContext(context);
        SDL_DestroyWindow(window);
        SDL_Quit();
        exit(0);
    }   
}