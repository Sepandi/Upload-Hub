#include "Aura/Aura.hpp"
#define WORLD_WIDTH 30
#define WORLD_HEIGHT 10
using namespace std;
using namespace Aura;
int main(){
    Window::CreateWindow();
    vector<Cube> ground;
    Vec3 originPos = Vec3(0,0,0);
    int groundIndexForInit = 0;
    for (int x=0;x<WORLD_WIDTH;x++){
        for (int z=0;z<WORLD_HEIGHT;z++){
            ground.push_back(Cube(Vec3(originPos.x+(x*0.25),1,originPos.z-(z*-0.25)),Vec3(0.25,0.25,0.25),"grass.png"));
            ground.at(groundIndexForInit).allowedSurfaces = {false,false,false,false,true,false};
            if (x == WORLD_WIDTH-1){
                ground.at(groundIndexForInit).allowedSurfaces.at(1) = true;
            }
            if (x == 0){
                ground.at(groundIndexForInit).allowedSurfaces.at(3) = true;
            }
            if (z == WORLD_HEIGHT-1){
                ground.at(groundIndexForInit).allowedSurfaces.at(0) = true;
            }
            groundIndexForInit++;
        }
    }
    int x = 0;
    glTranslatef(0,0,-10);
    glRotatef(30,1,0,0);
    while(true){
        Window::UpdateWindow();
        x++;
        int groundIndex = 0;
        for (int x=0;x<30;x++){
            for (int z=0;z<10;z++){
                ground.at(groundIndex).pos.x = originPos.x+(x*0.25);
                ground.at(groundIndex).pos.z = originPos.z+(z*0.25);
                groundIndex++;
            }
        }
        if (Window::isDown[SDL_SCANCODE_W]){
            originPos.z+=0.05;
        }
        if (Window::isDown[SDL_SCANCODE_S]){
            originPos.z-=0.05;
        }
        if (Window::isDown[SDL_SCANCODE_A]){
            originPos.x+=0.05;
        }
        if (Window::isDown[SDL_SCANCODE_D]){
            originPos.x-=0.05;
        }
        if (Window::isDown[SDL_SCANCODE_RIGHT]){
            glRotatef(1,0,1,0);
        }
        if (Window::isDown[SDL_SCANCODE_LEFT]){
            glRotatef(-1,0,1,0);
        }
        // Cube::Draw(cube);
        // Cube::Draw(cube1);
        // Cube::Draw(cube2);
        // Cube::Draw(cube3);
        // Cube::Draw(cube4);
        // Cube::Draw(cube5);
        // Cube::Draw(cube6);
        // Cube::Draw(cube7);
        // Cube::Draw(cube8);
        GLfloat light0_position[] = {  1, 0.5, 1,1};
        GLfloat light0_brightness[] = { 1, 1, 1, 1 };
        glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_brightness);
        glLightfv(GL_LIGHT0, GL_SPECULAR, light0_brightness);

        glShadeModel(GL_SMOOTH);
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        for (int x=0;x<ground.size();x++){
            Cube::Draw(ground[x]);
        }
        
        Utils::Log(ground.at(10).pos.x);
    }
    Window::Quit();
    
    
}