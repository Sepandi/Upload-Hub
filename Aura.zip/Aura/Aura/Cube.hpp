class Cube{
    public :
        Vec3 pos,size;
        GLuint textureID;
        int textureWidth, textureHeight, texturenrChannels;
        unsigned char *textureData;
        vector<bool> allowedSurfaces = {true,true,true,true,true,true};
        Cube(){}
        Cube(Vec3 _pos,Vec3 _size,std::string texturePath){
            pos.x = _pos.x;
            pos.y = _pos.y;
            pos.z = _pos.z;
            size.x = _size.x;
            size.y = _size.y;
            size.z = _size.z;    


            glGenTextures(1, &textureID);
            glBindTexture(GL_TEXTURE_2D, textureID);

            textureData = stbi_load(std::string(texturePath).c_str(), &textureWidth, &textureHeight, &texturenrChannels, 0);
            if(stbi_failure_reason())
                std::cout << stbi_failure_reason();
        }
        static void Draw(Cube cube){
            if(cube.pos.x < Window::width/(1*Window::width) && cube.pos.x > -(Window::width/(1*Window::width)) && cube.pos.z > -2 && cube.pos.z < 4){
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, cube.textureWidth, cube.textureHeight, 0, GL_RGBA,GL_UNSIGNED_BYTE, cube.textureData);
            glGenerateMipmap(GL_TEXTURE_2D);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
            
            //1
            if (cube.allowedSurfaces[0]){
                glEnable(GL_TEXTURE_2D);
                glBegin( GL_QUADS );
                glBindTexture( GL_TEXTURE_2D, cube.textureID);
                glTexCoord2f(0.00,0.5);glVertex3f(cube.pos.x            , cube.pos.y             ,cube.pos.z);
                glTexCoord2f(0.25,0.5);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y             ,cube.pos.z);
                glTexCoord2f(0.25,1.0);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z);
                glTexCoord2f(0.00,1.0);glVertex3f(cube.pos.x            , cube.pos.y+cube.size.y ,cube.pos.z);
                glEnd();
                glDisable(GL_TEXTURE_2D);
                //shadow
                glColor4f(0,0,0,0.2);
                glBegin( GL_QUADS );
                glVertex3f(cube.pos.x            , cube.pos.y             ,cube.pos.z+0.001);
                glVertex3f(cube.pos.x+cube.size.x, cube.pos.y             ,cube.pos.z+0.001);
                glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z+0.001);
                glVertex3f(cube.pos.x            , cube.pos.y+cube.size.y ,cube.pos.z+0.001);
                glColor4f(1,1,1,1);
                glEnd();
            }

            //2
            if (cube.allowedSurfaces[1]){
                glEnable(GL_TEXTURE_2D);
                glBegin( GL_QUADS );
                glBindTexture( GL_TEXTURE_2D, cube.textureID);
                glTexCoord2f(0.25,0.5);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y             ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.50,0.5);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y             ,cube.pos.z            );
                glTexCoord2f(0.50,1.0);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z            );
                glTexCoord2f(0.25,1.0);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z-cube.size.z);
                glEnd();
                glDisable(GL_TEXTURE_2D);
            }
            //3
            if (cube.allowedSurfaces[2]){
                glEnable(GL_TEXTURE_2D);
                glBegin( GL_QUADS );
                glBindTexture( GL_TEXTURE_2D, cube.textureID);
                glTexCoord2f(0.50,0.5);glVertex3f(cube.pos.x            , cube.pos.y             ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.75,0.5);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y             ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.75,1.0);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.50,1.0);glVertex3f(cube.pos.x            , cube.pos.y+cube.size.y ,cube.pos.z-cube.size.z);
                glEnd();
                glDisable(GL_TEXTURE_2D);
            }
            //4
            if (cube.allowedSurfaces[3]){
                glEnable(GL_TEXTURE_2D);
                glBegin( GL_QUADS );
                glBindTexture( GL_TEXTURE_2D, cube.textureID);
                glTexCoord2f(0.75,0.5);glVertex3f(cube.pos.x      , cube.pos.y             ,cube.pos.z-cube.size.z);
                glTexCoord2f(1.00,0.5);glVertex3f(cube.pos.x      , cube.pos.y             ,cube.pos.z            );
                glTexCoord2f(1.00,1.0);glVertex3f(cube.pos.x      , cube.pos.y+cube.size.y ,cube.pos.z            );
                glTexCoord2f(0.75,1.0);glVertex3f(cube.pos.x      , cube.pos.y+cube.size.y ,cube.pos.z-cube.size.z);
                glEnd();
                glDisable(GL_TEXTURE_2D);
            }


            // head ----------------------------------------------------------------------------------------------------------------
            //5
            if (cube.allowedSurfaces[4]){
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA,  cube.textureWidth, cube.textureHeight, 1, GL_RGBA,GL_UNSIGNED_BYTE,  cube.textureData);
                glGenerateMipmap(GL_TEXTURE_2D);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
                glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
                glEnable(GL_TEXTURE_2D);
                glBegin( GL_QUADS );
                glBindTexture( GL_TEXTURE_2D, cube.textureID);
                glTexCoord2f(0.00,0.0);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.24,0.0);glVertex3f(cube.pos.x            , cube.pos.y+cube.size.y ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.24,0.5);glVertex3f(cube.pos.x            , cube.pos.y+cube.size.y ,cube.pos.z            );
                glTexCoord2f(0.00,0.5);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y+cube.size.y ,cube.pos.z            );
                glEnd();
                glDisable(GL_TEXTURE_2D);
            }
            //6
            if (cube.allowedSurfaces[5]){
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, cube.textureWidth, cube.textureHeight, 1, GL_RGBA,GL_UNSIGNED_BYTE, cube.textureData);
                glGenerateMipmap(GL_TEXTURE_2D);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
                glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
                glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
                glEnable(GL_TEXTURE_2D);
                glBegin( GL_QUADS );
                glBindTexture( GL_TEXTURE_2D, cube.textureID);
                glTexCoord2f(0.24,0.0);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y    ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.50,0.0);glVertex3f(cube.pos.x            , cube.pos.y    ,cube.pos.z-cube.size.z);
                glTexCoord2f(0.50,0.5);glVertex3f(cube.pos.x            , cube.pos.y    ,cube.pos.z            );
                glTexCoord2f(0.24,0.5);glVertex3f(cube.pos.x+cube.size.x, cube.pos.y    ,cube.pos.z            );
                glEnd();
                glDisable(GL_TEXTURE_2D);
            }
            }
        }
};